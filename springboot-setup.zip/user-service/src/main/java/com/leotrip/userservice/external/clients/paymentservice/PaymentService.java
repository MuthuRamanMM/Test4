package com.leotrip.userservice.external.clients.paymentservice;

import com.leotrip.userservice.dto.request.PaymentRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="LEOTRIP-PAYMENT-SERVICE",url = "http://leotrip-payment-service/payment")
public interface PaymentService {
    @PostMapping
    long doPayment(@RequestBody PaymentRequest paymentRequest);


}
