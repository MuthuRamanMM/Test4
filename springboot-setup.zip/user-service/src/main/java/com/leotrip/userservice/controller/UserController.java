package com.leotrip.userservice.controller;


import com.leotrip.userservice.dto.request.PaymentRequest;
import com.leotrip.userservice.dto.request.UserCreateRequest;
import com.leotrip.userservice.services.UserService;
import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import lombok.RequiredArgsConstructor;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
@Log4j2
@RefreshScope

public class UserController {

    @Autowired
    private EurekaClient eurekaClient;
    @Value("${message}")
    private String testConfigserverRefresh;

    private final UserService userService;

    @PostMapping("/create")
    public ResponseEntity<Long> addProduct(@RequestBody UserCreateRequest userCreateRequest) {

        long userId = userService.createUser(userCreateRequest);
        return new ResponseEntity<>(userId, HttpStatus.CREATED);
    }
    @PostMapping("/test-payment-feignClient")
    public ResponseEntity<?> testPaymentFeignClient(@RequestBody PaymentRequest paymentRequest)
    {
        long paymentId=userService.tesPaymentClient(paymentRequest);
        return new ResponseEntity<>(paymentId,HttpStatus.OK);
    }

    @GetMapping("/check-config-server")
    public String checkConfigServer ()
    {

        return testConfigserverRefresh;
    }


    @GetMapping("/get-greeting-no-feign")
    public String greeting(Model model) {

        InstanceInfo service = eurekaClient
                .getApplication("leotrip-payment-service")
                .getInstances()
                .get(0);

        String hostName = service.getHostName();
        int port = service.getPort();

        // ...
        return hostName+port;
    }

    @GetMapping("/test-keycloak")
    public String TestKeycloak ()
    {

        return "keycloak verified successfully";
    }
}
