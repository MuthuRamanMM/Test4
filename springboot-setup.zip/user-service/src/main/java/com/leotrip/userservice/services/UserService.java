package com.leotrip.userservice.services;

import com.leotrip.userservice.dto.request.PaymentRequest;
import com.leotrip.userservice.dto.request.UserCreateRequest;
import com.leotrip.userservice.dto.request.UserLoginRequest;
import com.leotrip.userservice.dto.response.UserLoginResponse;

public interface UserService {

    long createUser(UserCreateRequest userLoginRequest);


    public void deleteUserById(long userId);

    long tesPaymentClient(PaymentRequest paymentRequest);
}
