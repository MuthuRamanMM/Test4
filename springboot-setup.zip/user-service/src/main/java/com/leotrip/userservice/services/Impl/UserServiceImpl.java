package com.leotrip.userservice.services.Impl;

import com.leotrip.userservice.dto.request.PaymentRequest;
import com.leotrip.userservice.dto.request.UserCreateRequest;
import com.leotrip.userservice.entity.Users;
import com.leotrip.userservice.exception.UserServiceCustomException;
import com.leotrip.userservice.external.clients.paymentservice.PaymentService;
import com.leotrip.userservice.repository.UserRepository;
import com.leotrip.userservice.services.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Log4j2
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    private final PaymentService paymentService;
    @Override
    public long createUser(UserCreateRequest userCreateRequest) {
        log.info("ProductServiceImpl | addProduct is called");

        Users users
                = Users.builder()
                .userName(userCreateRequest.getUserName())
                .email(userCreateRequest.getEmail())
                .password(userCreateRequest.getPassword())
                .build();

        users = userRepository.save(users);

        log.info("ProductServiceImpl | addProduct | Product Created");
        log.info("ProductServiceImpl | addProduct | Product Id : " + users.getId());
        return users.getId();

    }


    @Override
    public void deleteUserById(long userId) {
        log.info("Product id: {}", userId);

        if (!userRepository.existsById(userId)) {
            log.info("Im in this loop {}", !userRepository.existsById(userId));
            throw new UserServiceCustomException(
                    "Product with given with Id: " + userId + " not found:",
                    "PRODUCT_NOT_FOUND");
        }
        log.info("Deleting Product with id: {}", userId);
        userRepository.deleteById(userId);

    }

    @Override
    public long tesPaymentClient(PaymentRequest paymentRequest)
    {

        long id= paymentService.doPayment(paymentRequest);
        System.out.println("output id"+id);
        System.out.print("kkkkkkkkkkk................");
        return id;

    }

}
