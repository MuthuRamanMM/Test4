package com.leotrip.paymentservice.service;

import com.leotrip.paymentservice.dto.request.PaymentRequest;
import com.leotrip.paymentservice.dto.response.PaymentResponse;

public interface PaymentService {
    long doPayment(PaymentRequest paymentRequest);

    PaymentResponse getPaymentDetailsByOrderId(long orderId);
}
